"""
The AI Social Media Auditor
============================
Course   : Coding for Artificial Intelligence
Problem  : Problem Set 5.2 - Dictionaries, Sets, and Text Normalisation
Author   : (ROHIT KUMAR SINGH) A26MTAI0004
"""


import string
text = ("AI is changing the world. Ai is powering new tools and ai is helping researchers in their work also. The world loves AI and getting dependent on it")

word_counts = {}
for raw_word in text.split () :
    cleaned_word = raw_word.lower().strip(string.punctuation)
    if not cleaned_word :
        continue
    word_counts.setdefault(cleaned_word,0)
    word_counts[cleaned_word]+=1
print(word_counts)

platform_a_followers = ["u101","u102","u103","u104","u105"]
platform_b_followers = ["u103","u104","u106","u107"]


set_a = set(platform_a_followers)
set_b = set(platform_b_followers)
 
both_platforms = set_a & set_b   
only_a = set_a - set_b           
only_b = set_b - set_a          
either_only = set_a ^ set_b      
 
print("Follows on both platforms:", both_platforms)
print("Unique to platform a:", only_a)
print("Unique to platform b:", only_b)
print("Unique to exactly one platform:", either_only)
