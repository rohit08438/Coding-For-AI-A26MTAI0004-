# A chunk_size read has no idea where a line ends - it just grabs the
# next N bytes off disk, so almost every chunk boundary lands in the
# middle of some record. If you process each chunk as if it only held
# complete lines, the tail of one chunk and the head of the next both
# get misread as separate broken records. The leftover buffer fixes
# this: after splitting a chunk on b"\n", every piece except the last
# is guaranteed complete (it ended right before a newline), so only
# those get processed. The last piece might be finished or might not -
# there's no way to know until more bytes arrive - so it's held back
# and glued onto the front of the next chunk instead of being processed
# early.
#
# Author: Rohit Kumar Singh (A26MTAI0004)

import os
from typing import Tuple


def process_log_stream(file_path: str, chunk_size: int, /) -> Tuple[int, float]:
    """
    Reads a file in fixed-size byte chunks using a callable iterator.
    Returns total valid record count and running average value.
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Target path '{file_path}' not found.")

    valid_count = 0
    running_total = 0.0
    sentinel_found = False
    leftover = b""

    def handle_line(raw_line: bytes) -> None:
        nonlocal valid_count, running_total, sentinel_found
        line = raw_line.decode("utf-8").strip()
        if not line:
            return
        if line == "END_OF_LOG":
            sentinel_found = True
            return
        fields = line.split(",")
        if len(fields) != 3:
            return
        try:
            value = float(fields[2])
        except ValueError:
            return
        valid_count += 1
        running_total += value

    with open(file_path, "rb") as file_obj:
        for chunk in iter(lambda: file_obj.read(chunk_size), b""):
            leftover += chunk
            *complete_lines, leftover = leftover.split(b"\n")
            for raw_line in complete_lines:
                handle_line(raw_line)

    handle_line(leftover)

    if not sentinel_found:
        print("Warning: END_OF_LOG not found - file may be truncated.")

    mean_value = running_total / valid_count if valid_count else 0.0
    return valid_count, mean_value


if __name__ == "__main__":
    sample_log = (
        "2026-01-01T00:00:01,SENSOR_A,14.5\n"
        "2026-01-01T00:00:02,SENSOR_B,NaN_READING\n"
        "2026-01-01T00:00:03,SENSOR_C,\n"
        "2026-01-01T00:00:04,SENSOR_A,16.2\n"
        "2026-01-01T00:00:05,MALFORMED_ROW_TOO_FEW_FIELDS\n"
        "2026-01-01T00:00:06,SENSOR_B,15.0\n"
        "END_OF_LOG\n"
    )
    with open("sample_log.csv", "w", encoding="utf-8") as f:
        f.write(sample_log)

    for size in (1, 3, 7, 16, 32, 64, 128, 1000):
        result = process_log_stream("sample_log.csv", size)
        print(f"chunk_size={size} -> {result}")

# Submission Note: running the sample log at chunk_size=1 gave
# (3, 15.233333333333334), and running it again at chunk_size=1000
# (larger than the whole file) gave exactly the same result. That
# match is the real proof the leftover buffer works - at chunk_size=1
# almost every field is split across several reads, and the result
# still comes out identical to reading the file in one shot.
