# A check written only in __init__ runs once, at construction - if the
# attribute gets reassigned later anywhere in the program, nothing
# re-checks it. A property setter runs every single time the attribute
# is assigned, including inside __init__ (since self.target_path = ...
# there routes through the same setter). So the object can never end up
# holding an invalid path at any point in its lifetime, not just at
# creation.
#
# Author: Rohit Kumar Singh

import ast
import os
import re


class SourceAuditor:

    def __init__(self, target_path: str, /) -> None:
        self.target_path = target_path

    @property
    def target_path(self) -> str:
        return self._target_path

    @target_path.setter
    def target_path(self, value: str) -> None:
        if not os.path.exists(value):
            raise FileNotFoundError(
                f"Target path '{value}' does not exist.")
        self._target_path = value

    def audit_module_structure(self, file_contents: str, /, *,
                                max_line_length: int = 79) -> dict:
        """Parse source code string, evaluate PEP 8 compliance rules,
        and return a summary dictionary of violations."""
        tree = ast.parse(file_contents)
        top_level_funcs = [
            node for node in tree.body if isinstance(node, ast.FunctionDef)
        ]

        spacing_violations = []
        for earlier, later in zip(top_level_funcs, top_level_funcs[1:]):
            later_start = (later.decorator_list[0].lineno
                            if later.decorator_list else later.lineno)
            if later_start - earlier.end_lineno - 1 < 2:
                spacing_violations.append(later.name)

        lines = file_contents.split('\n')
        line_length_violations = []
        trailing_whitespace_violations = []
        colon_spacing_violations = []

        for line_no, line in enumerate(lines, start=1):
            if len(line) > max_line_length:
                line_length_violations.append(line_no)
            if line.strip() and line != line.rstrip():
                trailing_whitespace_violations.append(line_no)
            if re.search(r'\w:\S', line):
                colon_spacing_violations.append(line_no)

        return {
            "spacing_violations": spacing_violations,
            "line_length_violations": line_length_violations,
            "trailing_whitespace_violations": trailing_whitespace_violations,
            "colon_spacing_violations": colon_spacing_violations,
        }

    def verify_sdist_layout(self, directory_path: str, /) -> bool:
        setup_path = os.path.join(directory_path, "setup.py")
        readme_path = os.path.join(directory_path, "README.txt")
        if not (os.path.isfile(setup_path) and os.path.isfile(readme_path)):
            return False

        with open(setup_path, encoding="utf-8") as source_file:
            setup_contents = source_file.read()

        match = re.search(r'py_modules\s*=\s*\[(.*?)\]', setup_contents,
                           re.S)
        if not match:
            return False

        module_names = re.findall(r"['\"]([\w.]+)['\"]", match.group(1))
        return any(
            os.path.isfile(os.path.join(directory_path, f"{name}.py"))
            for name in module_names
        )


def _self_test_helper() -> None:
    """Kept top-level so the self-audit has more than one function to
    check spacing between."""
    pass


if __name__ == "__main__":
    assert not SourceAuditor(__file__).audit_module_structure(
        open(__file__, encoding="utf-8").read()
    )["spacing_violations"], (
        "Self-audit failed: spacing violations found."
    )
    print("Self-audit passed: no top-level function spacing violations.")
