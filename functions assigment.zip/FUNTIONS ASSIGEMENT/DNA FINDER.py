"""Python functions receive a reference to the actual object, 
not a copy.
Mutating data (like lists) inside a function will affect 
the variable outside the function.
It differs from "pass by value" because changes persist globally.
It differs from traditional "pass by reference" because Python 
assigns a new local name to the existing object."""

def search4letters(phrase: str, letters: str = 'ATCG') -> set:
    

    return set(letters).intersection(set(phrase))

print("TASK 1: search4letters")
print()
result1 = search4letters('TGGACC', 'GC')
print("Positional arguments:", result1)

result2 = search4letters(letters='CG', phrase='TGGACC')
print("Keyword arguments:", result2)

result3 = search4letters('TGGACC')
print("Default arguments:", result3)

print()


def analyze_sequence(sequence_list, marker):

    print(
        f"Inside Function (Start) - ID: {id(sequence_list)} "
        f"| Data: {sequence_list}"
    )

    sequence_list.append(marker)

    print(
        f"Inside Function (End) - ID: {id(sequence_list)} "
        f"| Data: {sequence_list}"
    )


dna_database = ['AATCCG', 'TGGCTA']

print(
    f"Global Scope (Before) - ID: {id(dna_database)} "
    f"| Data: {dna_database}"
)

analyze_sequence(dna_database, 'CGAT')

print(
    f"Global Scope (After) - ID: {id(dna_database)} "
    f"| Data: {dna_database}"
)

print()

dna_database = ['AATCCG', 'TGGCTA']

print(
    f"Global Scope (Before) - ID: {id(dna_database)} "
    f"| Data: {dna_database}"
)

analyze_sequence(dna_database[:], 'CGAT')

print(
    f"Global Scope (After) - ID: {id(dna_database)} "
    f"| Data: {dna_database}"
)

print()


def analyze_sequence_rebind(sequence_list, marker):

    print(
        f"Inside (Start) - ID: {id(sequence_list)}"
    )

    
    sequence_list = sequence_list + [marker]

    print(
        f"Inside (End) - ID: {id(sequence_list)} "
        f"| Data: {sequence_list}"
    )


dna_database = ['AATCCG', 'TGGCTA']

print(
    f"Global Scope (Before Bonus) - ID: {id(dna_database)} "
    f"| Data: {dna_database}"
)

analyze_sequence_rebind(dna_database, 'CGAT')

print(
    f"Global Scope (After Bonus) - ID: {id(dna_database)} "
    f"| Data: {dna_database}"
)

print()


print("EDGE CASES")
print()

print(
    "Empty phrase:",
    search4letters('')
)

print(
    "Mixed positional and keyword:",
    search4letters('TGGACC', letters='GC')
)

dna_database = ['AATCCG', 'TGGCTA']

print("Original database:", dna_database)

analyze_sequence(dna_database[:], 'CGAT')
analyze_sequence(dna_database[:], 'AAAA')

print("Database after repeated slice calls:", dna_database)
